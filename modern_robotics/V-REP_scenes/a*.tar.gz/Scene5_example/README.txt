# A* algorithm
A* algorithm writen by C++.
# Running 
```
$ cd code 
$ make
$ ./a_star
```